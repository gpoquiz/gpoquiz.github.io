---
environment: html
title: HTML 
type: Web Development
---
Markup language for documents designed to be displayed in a web browser.
Assisted by css for styling purposes.