---
project: website
environment: html
title: This Website
type: Web Development
---

This website was made primarily as a resume material, secondarily
to learn HTML/CSS.

[http://jmcglone.com/guides/github-pages/](http://jmcglone.com/guides/github-pages/)
helped with setting up Github Pages and initial Jekyll organization.

The [Jekyll Step by Step Tutorial](https://jekyllrb.com/docs/step-by-step/01-setup/)
was great for finishing up my Jekyll setup (Obviously).  Jekyll as a whole
is also super helpful for keeping my workspace organized (Mostly).

I used [this invaluable site](https://www.google.com/) for any general troubleshooting
I had.  Would definitely recommend it.
